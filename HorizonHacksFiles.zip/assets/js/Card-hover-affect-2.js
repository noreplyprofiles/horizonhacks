$(".hover").mouseleave(
  function () {
    $(this).removeClass("hover");
  }
);
